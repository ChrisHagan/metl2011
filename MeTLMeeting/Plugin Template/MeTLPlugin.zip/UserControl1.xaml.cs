﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Ink;
using System.Windows.Interop;
using System.Windows.Media;
using SandRibbon;
using System.Windows.Input;

namespace MeTLPlugin
{
    public partial class PluginMain : System.Windows.Controls.UserControl
    {

        public PluginMain()
        {
            InitializeComponent();
        }
    }
}